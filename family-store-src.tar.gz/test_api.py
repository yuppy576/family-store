import urllib.request
import json
import time

def http_post(url, data, headers=None):
    if headers is None:
        headers = {}
    req = urllib.request.Request(url, data=json.dumps(data).encode(), headers=headers)
    try:
        resp = urllib.request.urlopen(req, timeout=10)
        return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        return {'status': e.code, 'body': e.read().decode()}
    except Exception as e:
        return {'error': str(e)}

def http_get(url, headers=None):
    if headers is None:
        headers = {}
    req = urllib.request.Request(url, headers=headers)
    try:
        resp = urllib.request.urlopen(req, timeout=10)
        return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        return {'status': e.code, 'body': e.read().decode()}
    except Exception as e:
        return {'error': str(e)}

print("=== 测试家族门店管理系统 API ===")

print("\n1. 测试登录接口...")
login_data = http_post('http://127.0.0.1:8081/v1/users/login', {'email': 'admin@test.com', 'password': 'test123456'})
print(f"登录响应: {json.dumps(login_data)[:500]}")

token = login_data.get('data', {}).get('token', '')
if token:
    print(f"Token获取成功: {token[:30]}...")
    
    print("\n2. 测试用户信息接口 (/me)...")
    user_data = http_get('http://127.0.0.1:8081/v1/users/me', {'Authorization': f'Bearer {token}'})
    print(f"用户信息: {json.dumps(user_data)[:500]}")
    
    print("\n3. 测试审计日志接口...")
    audit_data = http_get('http://127.0.0.1:8081/v1/audit-logs/?skip=0&limit=10', {'Authorization': f'Bearer {token}'})
    print(f"审计日志响应: {json.dumps(audit_data)[:500]}")
    
    print("\n4. 测试商品分类列表...")
    category_data = http_get('http://127.0.0.1:8081/v1/categories/', {'Authorization': f'Bearer {token}'})
    print(f"分类列表: {json.dumps(category_data)[:500]}")
    
    print("\n5. 测试创建分类（生成审计日志）...")
    unique_name = f'测试分类_{int(time.time())}'
    new_category = http_post('http://127.0.0.1:8081/v1/categories/', {'name': unique_name, 'description': '测试分类描述'}, {'Authorization': f'Bearer {token}'})
    print(f"创建分类响应: {json.dumps(new_category)[:500]}")
    
    print("\n6. 再次查询审计日志（验证日志记录）...")
    audit_data2 = http_get('http://127.0.0.1:8081/v1/audit-logs/?skip=0&limit=10', {'Authorization': f'Bearer {token}'})
    print(f"审计日志响应: {json.dumps(audit_data2)[:1000]}")
    
    print("\n7. 测试商品列表...")
    product_data = http_get('http://127.0.0.1:8081/v1/products/', {'Authorization': f'Bearer {token}'})
    print(f"商品列表: {json.dumps(product_data)[:500]}")
    
    print("\n8. 测试寄卖品列表...")
    consignment_data = http_get('http://127.0.0.1:8081/v1/consignment/items', {'Authorization': f'Bearer {token}'})
    print(f"寄卖品列表: {json.dumps(consignment_data)[:500]}")
    
    print("\n9. 测试供应商列表...")
    supplier_data = http_get('http://127.0.0.1:8081/v1/suppliers/', {'Authorization': f'Bearer {token}'})
    print(f"供应商列表: {json.dumps(supplier_data)[:500]}")
else:
    print("登录失败")

print("\n=== API测试完成 ===")
