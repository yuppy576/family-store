DROP TABLE IF EXISTS "audit_logs";
